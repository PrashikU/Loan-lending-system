import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { DateFormatPipe } from './date-format.pipe';
import { FormatTextPipe } from './format-text.pipe';
import { LoanTypesComponent } from './components/loan-types/loan-types.component';
import { LoanLendingFormComponent } from './components/loan-lending-form/loan-lending-form.component';
import { UserLoansListComponent } from './components/user-loans-list/user-loans-list.component';
import { UserLoanDetailComponent } from './components/user-loan-detail/user-loan-detail.component';
import { UserLoanEditComponent } from './components/user-loan-edit/user-loan-edit.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    DateFormatPipe,
    FormatTextPipe,
    LoanTypesComponent,
    LoanLendingFormComponent,
    UserLoansListComponent,
    UserLoanDetailComponent,
    UserLoanEditComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgbModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
