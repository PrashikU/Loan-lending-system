import { Component,OnInit } from '@angular/core';
import { LoanService } from '../../Service/loan.service';

@Component({
  selector: 'app-loan-types',
  templateUrl: './loan-types.component.html',
  styleUrl: './loan-types.component.css'
})
export class LoanTypesComponent implements OnInit {
  loanTypes: any[] = [];

  constructor(private loanService: LoanService) {}

  ngOnInit(): void {
    this.loanService.getLoanTypes().subscribe((data:any) => {
      this.loanTypes = data;
    });
  }
}
