import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LoanLendingFormComponent } from './loan-lending-form.component';

describe('LoanLendingFormComponent', () => {
  let component: LoanLendingFormComponent;
  let fixture: ComponentFixture<LoanLendingFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [LoanLendingFormComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(LoanLendingFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
