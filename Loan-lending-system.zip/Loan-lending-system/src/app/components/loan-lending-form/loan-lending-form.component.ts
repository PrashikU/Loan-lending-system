import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoanService } from '../../Service/loan.service';

@Component({
  selector: 'app-loan-lending-form',
  templateUrl: './loan-lending-form.component.html',
  styleUrl: './loan-lending-form.component.css'
})
export class LoanLendingFormComponent implements OnInit {
  userLoan = {
    fullName: '',
    dob: '',
    mobile: '',
    loanType: '',
    principal: 0,
    rate: 0,
    time: 0,
    si: 0,
    totalAmount: 0
  };
  loanTypes: any[] = [];

  constructor(private loanService: LoanService, private router: Router) {}

  ngOnInit(): void {
    this.loanService.getLoanTypes().subscribe((data:any) => {
      this.loanTypes = data;
    });
  }

  calculate(): void {
    const P = this.userLoan.principal;
    const R = this.userLoan.rate;
    const T = this.userLoan.time;
    const SI = (P * R * T/12) / 100;
    this.userLoan.si = SI;
    this.userLoan.totalAmount = P + SI;
  }

  onSubmit(form: any): void {
    if (form.valid) {
      this.loanService.addUserLoan(this.userLoan).subscribe(() => {
        this.router.navigate(['/user-loans']);
      });
    }
  }

  onCancel(): void {
    this.router.navigate(['/loan-types']);
  }
}
