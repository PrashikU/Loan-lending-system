import { Component, OnInit } from '@angular/core';
import { LoanService } from '../../Service/loan.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user-loans-list',
  templateUrl: './user-loans-list.component.html',
  styleUrl: './user-loans-list.component.css'
})
export class UserLoansListComponent implements OnInit {
  userLoans: any[] = [];

  constructor(private loanService: LoanService, private router: Router) {}

  ngOnInit(): void {
    this.loanService.getUserLoans().subscribe((data:any) => {
      this.userLoans = data;
    });
  }

  viewDetail(id: number): void {
    this.router.navigate([`/user-loan/${id}`]);
  }

  editLoan(id: number): void {
    this.router.navigate([`/edit-user-loan/${id}`]);
  }

  deleteLoan(id: number): void {
    this.loanService.deleteUserLoan(id).subscribe(() => {
      this.userLoans = this.userLoans.filter((loan) => loan.id !== id);
    });
  }
}
