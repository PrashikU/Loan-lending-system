import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserLoansListComponent } from './user-loans-list.component';

describe('UserLoansListComponent', () => {
  let component: UserLoansListComponent;
  let fixture: ComponentFixture<UserLoansListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [UserLoansListComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(UserLoansListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
