import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserLoanDetailComponent } from './user-loan-detail.component';

describe('UserLoanDetailComponent', () => {
  let component: UserLoanDetailComponent;
  let fixture: ComponentFixture<UserLoanDetailComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [UserLoanDetailComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(UserLoanDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
