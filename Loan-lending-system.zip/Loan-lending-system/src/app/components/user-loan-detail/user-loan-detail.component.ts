import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { LoanService } from '../../Service/loan.service';

@Component({
  selector: 'app-user-loan-detail',
  templateUrl: './user-loan-detail.component.html',
  styleUrl: './user-loan-detail.component.css'
})
export class UserLoanDetailComponent implements OnInit {
  userLoan: any = {};

  constructor(private route: ActivatedRoute, private loanService: LoanService, private router: Router) {}

  ngOnInit(): void {
    const id:any = this.route.snapshot.paramMap.get('id');
    this.loanService.getUserLoan(id).subscribe((data) => {
      this.userLoan = data;
    });
  }

  goBack(): void {
    this.router.navigate(['/user-loans']);
  }
}
