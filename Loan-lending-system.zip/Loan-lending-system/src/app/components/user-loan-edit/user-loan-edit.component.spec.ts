import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserLoanEditComponent } from './user-loan-edit.component';

describe('UserLoanEditComponent', () => {
  let component: UserLoanEditComponent;
  let fixture: ComponentFixture<UserLoanEditComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [UserLoanEditComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(UserLoanEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
