import { Component, OnInit } from '@angular/core';
LoanService
import { ActivatedRoute, Router } from '@angular/router';
import { LoanService } from '../../Service/loan.service';
@Component({
  selector: 'app-user-loan-edit',
  templateUrl: './user-loan-edit.component.html',
  styleUrl: './user-loan-edit.component.css'
})
export class UserLoanEditComponent implements OnInit {
  userLoan: any = {};
  loanTypes: any[] = [];

  constructor(
    private loanService: LoanService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    const id:any = this.route.snapshot.paramMap.get('id');
    this.loanService.getLoanTypes().subscribe((data:any) => {
      this.loanTypes = data;
      console.warn(this.loanTypes);
      
    });
    this.loanService.getUserLoan(id).subscribe((data:any) => {
      this.userLoan = data;
    });
  }

  calculate(): void {
    const P = this.userLoan.principal;
    const R = this.userLoan.rate;
    const T = this.userLoan.time;
    const SI = (P * R * T) / 100;
    this.userLoan.si = SI;
    this.userLoan.totalAmount = P + SI;
  }

  onSubmit(form: any): void {
    const id:any = this.route.snapshot.paramMap.get('id');
    if (form.valid) {
      this.loanService.updateUserLoan(id, this.userLoan).subscribe(() => {
        this.router.navigate(['/user-loans']);
      });
    }
  }

  onCancel(): void {
    this.router.navigate(['/user-loans']);
  }
}
