import { FormatTextPipe } from './format-text.pipe';

describe('FormatTextPipe', () => {
  it('create an instance', () => {
    const pipe = new FormatTextPipe();
    expect(pipe).toBeTruthy();
  });
});
