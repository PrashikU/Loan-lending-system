import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class LoanService {
  private apiUrl = 'http://localhost:3000';

  constructor(private http: HttpClient) {}

// Fetches the list of loan types from 
  getLoanTypes() {
    return this.http.get(`${this.apiUrl}/loanTypes`);
  }

   // Fetches all user loans from 
  getUserLoans() {
    return this.http.get(`${this.apiUrl}/userLoans`);
  }

   // Fetches the details of a specific user loan based on the given id
  getUserLoan(id: number) {
    return this.http.get(`${this.apiUrl}/userLoans/${id}`);
  }

  // Adds a new user loan to the db.json
  addUserLoan(loan: any){
    return this.http.post(`${this.apiUrl}/userLoans`, loan);
  }

  // Updates an existing user loan based on the given id
  updateUserLoan(id: number, loan: any){
    return this.http.put(`${this.apiUrl}/userLoans/${id}`, loan);
  }
  
   // Deletes a specific user loan based on the given id
  deleteUserLoan(id: number){
    return this.http.delete(`${this.apiUrl}/userLoans/${id}`);
  }
}
