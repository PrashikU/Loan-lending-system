import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoanTypesComponent } from './components/loan-types/loan-types.component';
import { UserLoansListComponent } from './components/user-loans-list/user-loans-list.component';
import { LoanLendingFormComponent } from './components/loan-lending-form/loan-lending-form.component';
import { UserLoanDetailComponent } from './components/user-loan-detail/user-loan-detail.component';
import { UserLoanEditComponent } from './components/user-loan-edit/user-loan-edit.component';

const routes: Routes = [
  { path: 'loan-types', component: LoanTypesComponent },
  { path: 'loan-lending', component: LoanLendingFormComponent },
  { path: 'user-loans', component: UserLoansListComponent },
  { path: 'user-loan/:id', component: UserLoanDetailComponent },
  { path: 'edit-user-loan/:id', component: UserLoanEditComponent },
  { path: '', redirectTo: '/loan-types', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
